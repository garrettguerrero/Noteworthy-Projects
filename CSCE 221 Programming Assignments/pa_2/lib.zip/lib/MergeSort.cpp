#include "SortLib.h"
#include <iostream>

using std::cout, std::endl;
template <typename T>
void SortLib::MergeSort(T arr[], int size) {
  if (size == 1) {
    //cout << "returning" << endl;
    return;
  }
  // split the array into two new arrays
  // cout <<"arr (size: " << size << "): ";
  // for (int i = 0; i < size; i++) {
  //   cout << arr[i] << ", ";
  // }
  //cout << endl;
  int size_1;
  int size_2;
  if (size % 2 != 0) {
    size_1 = (size / 2);
    size_2 = (size / 2) + 1;
  } else {
    size_1 = size / 2;
    size_2 = size / 2;
  }
  T* arr_1 = new T[size_1];
  T* arr_2 = new T[size_2];

  int i;
  for (i = 0; i < size_1; i++) {
    arr_1[i] = arr[i];
  }

  for (i = 0; i < size_2; i++) {
    arr_2[i] = arr[size_1 + i];
  }
  // if size is not 1, call merge sort for each half

  // cout <<"arr_1 (size: " << size_1 << "): ";
  // for (int i = 0; i < size_1; i++) {
  //   cout << arr_1[i] << ", ";
  // }
  // cout << endl;
  //
  // cout << "arr_2 (size: " << size_2 << "): ";
  // for (int i = 0; i < size_2; i++) {
  //   cout << arr_2[i] << ", ";
  // }
  // cout << endl;

  MergeSort(arr_1, size_1);
  MergeSort(arr_2, size_2);

  // cout <<"arr_1 (size: " << size_1 << "): ";
  // for (int i = 0; i < size_1; i++) {
  //   cout << arr_1[i] << ", ";
  // }
  // cout << endl;
  //
  // cout << "arr_2 (size: " << size_2 << "): ";
  // for (int i = 0; i < size_2; i++) {
  //   cout << arr_2[i] << ", ";
  // }
  // cout << endl;
  //
  // cout << size << endl;


  // combine the two arrays, sorting them as they are placed into arr
  int index_1 = 0;
  int index_2 = 0;
  i = 0;
  while (index_1 < size_1 && index_2 < size_2) {
    if (arr_1[index_1] < arr_2[index_2])
      arr[i++] = arr_1[index_1++];
    else
      arr[i++] = arr_2[index_2++];
  }

  while (index_1 < size_1)
    arr[i++] = arr_1[index_1++];

  while (index_2 < size_2)
    arr[i++] = arr_2[index_2++];

  // cout <<"end arr (size: " << size << "): ";
  // for (int i = 0; i < size; i++) {
  //   cout << arr[i] << ", ";
  // }
  // cout << endl;

  delete[] arr_1;
  delete[] arr_2;
}

template void SortLib::MergeSort(int*, int);

//https://www.geeksforgeeks.org/merge-sort/
//https://www.geeksforgeeks.org/merge-two-sorted-arrays/
