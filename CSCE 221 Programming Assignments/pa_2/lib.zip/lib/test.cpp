#include <iostream>
#include "BubbleSort.cpp"
#include "MergeSort.cpp"

using std::cout, std::endl;

int main() {
  const int size = 10;
  int arr[size] = {2, 4, 1, 5, 3, 9, 0, 28, 17, 89};

  cout << "unsorted: ";
  for (int i = 0; i < size; i++) {
    cout << arr[i] << ", ";
  }
  cout << endl;
  SortLib::MergeSort(arr, size);
  cout << "sorted: ";
  for (int i = 0; i < size; i++) {
    cout << arr[i] << ", ";
  }
  cout << endl;


  return 0;
}
